"use strict";
exports.id = 3530;
exports.ids = [3530];
exports.modules = {

/***/ 3530:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ layout_2)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./src/layout/footer/footer-2.jsx



const FooterTwo = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("footer", {
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "footer-area pt-105",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "tp-footer-top pb-25",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "container",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "row",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-lg-4 col-md-6",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "tp-footer-widget footer-2-col-1 mb-40 wow fadeInUp",
                                            "data-wow-delay": ".2s",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "tp-footer-widget__content mb-95",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            children: "FEEL FREE TO CONTACT US"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                            className: "tp-footer-widget__contact mb-20",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                href: "tel:1300-343-481",
                                                                children: "1300-343-481"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                            href: "mailto:CARE@VSERVEAUSTRALIA.COM.AU",
                                                            children: "CARE@VSERVEAUSTRALIA.COM.AU"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "tp-footer-widget__sub-sec",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "tp-footer-widget__sub-title mb-5",
                                                            children: "Career"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                            children: [
                                                                "Nam eget dui vel quam sodales semper quis porttitor",
                                                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                                                " tortor. Vivamus quis ex nulla ...Nam eget dui vel quam ",
                                                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                                                " sodales semper quis porttitor tortor."
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-lg-4 col-md-6",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "tp-footer-widget footer-2-col-2 mb-40 wow fadeInUp",
                                            "data-wow-delay": ".4s",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "tp-footer-widget__title mb-15",
                                                    children: "Useful links"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "tp-footer-widget__links mb-35",
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                    href: "/contact",
                                                                    children: "Contact us"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                    href: "/about",
                                                                    children: "About us"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                    href: "/services-details",
                                                                    children: "Services"
                                                                })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "tp-footer-widget__sub-sec",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "tp-footer-widget__sub-title mb-10",
                                                            children: "Opening Hours"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "tp-footer-widget__list",
                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                        children: "Office Hours: 8AM - 11PM"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                        children: "Office Hours: 8AM - 11PM"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                        children: "Sunday - Wekend Day"
                                                                    })
                                                                ]
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-lg-4 col-md-6",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "tp-footer-widget footer-2-col-4 mb-40 wow fadeInUp",
                                            "data-wow-delay": ".8s",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "tp-footer-widget__title mb-15",
                                                    children: "Contact Info"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "tp-footer-widget__links mb-120",
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                children: "VSERVE AUSTRALIA DISABILITY CARE, NSW 2000, AUSTRALIA"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                    href: "tel:1300-343-481",
                                                                    children: "1300-343-481"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                    href: "mailto:CARE@VSERVEAUSTRALIA.COM.AU",
                                                                    children: "CARE@VSERVEAUSTRALIA.COM.AU"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                children: "Office Hours: 8AM - 11PM"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                children: "Sunday - Wekend Day"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "tp-footer-widget__social fw-social",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                            href: "#",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                className: "fa-brands fa-facebook-f"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                            href: "#",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                className: "fa-brands fa-twitter"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                            href: "#",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                className: "fa-brands fa-instagram"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                            href: "#",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                className: "fa-light fa-basketball"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                            href: "#",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                className: "fa-brands fa-youtube"
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "footer-area-bottom fw-border",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "container",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "row",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-xl-6 col-lg-6 col-md-12 col-12",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "footer-widget__copyright copyright-white",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                children: [
                                                    "\xa9 Copyright \xa9",
                                                    new Date().getFullYear(),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                        href: "/",
                                                        children: [
                                                            " ",
                                                            "Vserve"
                                                        ]
                                                    }),
                                                    ".",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        children: " All Rights Reserved Copyright"
                                                    })
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-xl-6 col-lg-6 col-md-12 col-12",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "footer-widget__copyright-info info-direction"
                                        })
                                    })
                                ]
                            })
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const footer_2 = (FooterTwo);

// EXTERNAL MODULE: ./src/layout/header/header-two.jsx
var header_two = __webpack_require__(9703);
;// CONCATENATED MODULE: ./src/layout/layout-2.jsx




const LayoutTwo = ({ children  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(header_two/* default */.Z, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                children: children
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(footer_2, {})
        ]
    });
};
/* harmony default export */ const layout_2 = (LayoutTwo);


/***/ })

};
;