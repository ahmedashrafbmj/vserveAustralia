"use strict";
exports.id = 532;
exports.ids = [532];
exports.modules = {

/***/ 532:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



// progress_data
const progress_data = [
    {
        id: 1,
        icon: "flaticon-approval",
        img: "/assets/img/shape/navtabs-01.png",
        title: "Generate Proposal",
        des: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                "Testing Begins many varios ",
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                " suffered alten in some"
            ]
        })
    },
    {
        id: 2,
        icon: "flaticon-flask",
        img: "/assets/img/shape/navtabs-01.png",
        title: "Testing Begins",
        des: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                "There are many varios passages ",
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                "suffered alten in some"
            ]
        })
    },
    {
        id: 3,
        icon: "flaticon-report",
        img: "",
        title: "Reports Delivered",
        des: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                "There are many varios passages ",
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                "suffered alten in some"
            ]
        })
    }
];
// tab_content
const tab_content = [
    {
        id: 1,
        tab_id: "profile-tab-pane",
        aria_labelledby: "profile-tab",
        header: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                "Your full service lab for clinical trials. Our process is to ensure the generation of ",
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                " accurate and precise findings"
            ]
        }),
        title: "Our Mission is Give You Always Best Results.",
        des_1: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: "Exerci tation ullamcorper suscipit lobortis nisl aliquip ex ea commodo claritatem insitamconse quat.Exerci tation ullamcorper suscipit loborti excommodo habent claritatem insitamconse quat.Exerci tationlobortis nisl aliquip ex ea commodo habent claritatem insitamconse quat."
        }),
        des_2: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: "Exerci tation ullamcorper suscipit lobortis nisl aliquip ex ea commodo claritatem insitamconse quat.Exerci tation ullamcorper suscip"
        }),
        images: [
            {
                order: "order-lg-1",
                img: "/assets/img/tab/tab-thumb-03.jpg"
            },
            {
                order: "order-lg-3",
                img: "/assets/img/tab/tab-thumb-04.jpg"
            }
        ]
    },
    {
        id: 2,
        tab_id: "contact-tab-pane",
        aria_labelledby: "contact-tab",
        header: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                "Your full service lab for clinical trials. Our process is to ensure the generation of ",
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                " accurate and precise findings"
            ]
        }),
        title: "We are Trusted by over 25000+ of customers",
        des_1: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: "Exerci tation ullamcorper suscipit lobortis nisl aliquip ex ea commodo claritatem insitamconse quat.Exerci tation ullamcorper suscipit loborti excommodo habent claritatem insitamconse quat.Exerci tationlobortis nisl aliquip ex ea commodo habent claritatem insitamconse quat."
        }),
        des_2: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: "Exerci tation ullamcorper suscipit lobortis nisl aliquip ex ea commodo claritatem insitamconse quat.Exerci tation ullamcorper suscip"
        }),
        images: [
            {
                order: "order-lg-1",
                img: "/assets/img/tab/tab-thumb-01.jpg"
            },
            {
                order: "order-lg-3",
                img: "/assets/img/tab/tab-thumb-02.jpg"
            }
        ]
    }
];
const NavTab = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            className: "nav-area tp-common-area pt-130 pb-80",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "container",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                        className: "nav tp-nav-tavs mb-70",
                        id: "myTab",
                        role: "tablist",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: "nav-item",
                                role: "presentation",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "nav-link active",
                                    id: "home-tab",
                                    "data-bs-toggle": "tab",
                                    "data-bs-target": "#home-tab-pane",
                                    type: "button",
                                    role: "tab",
                                    "aria-controls": "home-tab-pane",
                                    "aria-selected": "true",
                                    tabIndex: "-1",
                                    children: "Our Process"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: "nav-item",
                                role: "presentation",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "nav-link",
                                    id: "profile-tab",
                                    "data-bs-toggle": "tab",
                                    "data-bs-target": "#profile-tab-pane",
                                    type: "button",
                                    role: "tab",
                                    "aria-controls": "profile-tab-pane",
                                    "aria-selected": "false",
                                    tabIndex: "-1",
                                    children: "OUr Mission"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: "nav-item",
                                role: "presentation",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "nav-link",
                                    id: "contact-tab",
                                    "data-bs-toggle": "tab",
                                    "data-bs-target": "#contact-tab-pane",
                                    type: "button",
                                    role: "tab",
                                    "aria-controls": "contact-tab-pane",
                                    "aria-selected": "false",
                                    tabIndex: "-1",
                                    children: "OUr Value"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "tab-content",
                        id: "myTabContent",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "tab-pane fade show active",
                                id: "home-tab-pane",
                                role: "tabpanel",
                                "aria-labelledby": "home-tab",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "nav-info d-flex justify-content-center text-center mb-75",
                                        children: [
                                            "Your full service lab for clinical trials. Our process is to ensure the generation of ",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                            " accurate and precise findings"
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "row",
                                        children: progress_data.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "col-xl-4 col-lg-4 col-md-6",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "navtabs nav-primary p-relative text-center mb-40",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "navtabs__icon mb-35",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                className: item.icon
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "navtabs__content",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                                                    className: "navtabs__title mb-25 mb-10",
                                                                    children: item.title
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                    children: item.des
                                                                })
                                                            ]
                                                        }),
                                                        item.img && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "navtabs__shape d-none d-lg-block",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                                placeholder: "image",
                                                                width: 0,
                                                                height: 0,
                                                                sizes: "100vw",
                                                                style: {
                                                                    width: "100%",
                                                                    height: "auto"
                                                                },
                                                                alt: "vserve",
                                                                src: item?.img
                                                            })
                                                        })
                                                    ]
                                                })
                                            }, item.id))
                                    })
                                ]
                            }),
                            tab_content.map((item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "tab-pane fade",
                                    id: `${item.tab_id}`,
                                    role: "tabpanel",
                                    "aria-labelledby": `${item.aria_labelledby}`,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "nav-info d-flex justify-content-center text-center mb-75",
                                            children: item.header
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-xl-6 col-lg-6 col-md-12 order-lg-2",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "nabmission mb-30",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "nabmission__content text-center ml-50 mr-50 pt-20",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                                    className: "nabmission__title mb-35",
                                                                    children: item.title
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                    className: "mb-35",
                                                                    children: item.des_1
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                    children: item.des_2
                                                                })
                                                            ]
                                                        })
                                                    })
                                                }),
                                                item.images.map((img, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: `col-xl-3 col-lg-3 col-md-6 ${img.order}`,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "nabthumb mb-30",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                                placeholder: "image",
                                                                width: 0,
                                                                height: 0,
                                                                sizes: "100vw",
                                                                style: {
                                                                    width: "100%",
                                                                    height: "auto"
                                                                },
                                                                alt: "vserve",
                                                                src: img.img
                                                            })
                                                        })
                                                    }, i))
                                            ]
                                        })
                                    ]
                                }, item.id))
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavTab);


/***/ })

};
;