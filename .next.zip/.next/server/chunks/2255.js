"use strict";
exports.id = 2255;
exports.ids = [2255];
exports.modules = {

/***/ 2255:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ pricing_area)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/data/pricing-data.js
const pricing_data = [
    {
        id: 1,
        color: "",
        title: "Basic Care",
        price: 89,
        time: "monthly",
        sub_title: "Basic Health Check",
        class: "",
        btn_color: "",
        price_features: [
            {
                active: "",
                list: "Complete Blood Count"
            },
            {
                active: "",
                list: "Liver Function Blood Test"
            },
            {
                active: "",
                list: "Heart Disease Blood Tests"
            },
            {
                active: "tp-price__inactive",
                list: "Cholesterol / Lipid Levels"
            },
            {
                active: "tp-price__inactive",
                list: "Sexually Transmitted Diseases"
            },
            {
                active: "tp-price__inactive",
                list: " Male / Female General Health"
            }
        ]
    },
    {
        id: 2,
        color: "tp-pink-btn",
        title: "Essential Care",
        price: 149,
        time: "monthly",
        sub_title: "Gold Health Check",
        class: "active more-services-price",
        btn_color: "tp-pink-btn",
        price_features: [
            {
                active: "",
                list: "Complete Blood Count"
            },
            {
                active: "",
                list: "Liver Function Blood Test"
            },
            {
                active: "",
                list: "Heart Disease Blood Tests"
            },
            {
                active: "tp-price__inactive",
                list: "Cholesterol / Lipid Levels"
            },
            {
                active: "tp-price__inactive",
                list: "Sexually Transmitted Diseases"
            },
            {
                active: "tp-price__inactive",
                list: "Male / Female General Health"
            },
            {
                active: "tp-price__inactive",
                list: "Sexually Transmitted Diseases"
            }
        ]
    },
    {
        id: 3,
        color: "tp-pink-btn",
        title: "Essential Care",
        price: 249,
        time: "yearly",
        sub_title: "Platinum Health Check",
        class: "tp-yearly-price",
        btn_color: "tp-green-btn",
        price_features: [
            {
                active: "",
                list: "Complete Blood Count"
            },
            {
                active: "",
                list: "Liver Function Blood Test"
            },
            {
                active: "",
                list: "Heart Disease Blood Tests"
            },
            {
                active: "tp-price__inactive",
                list: "Cholesterol / Lipid Levels"
            },
            {
                active: "tp-price__inactive",
                list: "Sexually Transmitted Diseases"
            },
            {
                active: "tp-price__inactive",
                list: "Male / Female General Health"
            }
        ]
    }
];
/* harmony default export */ const data_pricing_data = (pricing_data);

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./src/common/pricing-area.jsx




const PricingArea = ({ dark , p_bottom  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
            className: `pricing-area ${dark ? "theme-bg pt-125" : ""} ${p_bottom ? "" : "pt-120"} pb-90`,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row text-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-12 col-md-12 col-12",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "tp-section",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "tp-section__sub-title left-line right-line mb-20",
                                        children: "Price & Plan"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: `tp-section__title ${dark ? "title-white" : ""} mb-70`,
                                        children: "Choose Your Plan"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row g-0 align-items-center",
                        children: data_pricing_data.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-lg-4 col-md-6",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: `tp-price ${item.class} ${dark ? "tp-white-price" : ""} mb-40`,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "tp-price__badge mb-45",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: item.title
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "tp-price__heading mb-45",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "tp-price__content",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h4", {
                                                        className: "tp-price__value mb-25",
                                                        children: [
                                                            "$",
                                                            item.price,
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                                children: [
                                                                    "/",
                                                                    item.time
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        children: item.sub_title
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "tp-price__features tp-yearly-list mb-55",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                                children: item.price_features.map((list, i)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                        className: `${list.active}`,
                                                        children: list.list
                                                    }, i))
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: `tp-price__btn ${item.btn_color} `,
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                href: "/contact",
                                                children: [
                                                    "Purchase Now",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                            width: "22",
                                                            height: "8",
                                                            viewBox: "0 0 22 8",
                                                            fill: "none",
                                                            xmlns: "http://www.w3.org/2000/svg",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                                d: "M21.3536 4.35356C21.5488 4.15829 21.5488 3.84171 21.3536 3.64645L18.1716 0.464468C17.9763 0.269206 17.6597 0.269205 17.4645 0.464468C17.2692 0.65973 17.2692 0.976312 17.4645 1.17157L20.2929 4L17.4645 6.82843C17.2692 7.02369 17.2692 7.34027 17.4645 7.53554C17.6597 7.7308 17.9763 7.7308 18.1716 7.53554L21.3536 4.35356ZM-4.37114e-08 4.5L21 4.5L21 3.5L4.37114e-08 3.5L-4.37114e-08 4.5Z",
                                                                fill: "white"
                                                            })
                                                        })
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            }, item.id))
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const pricing_area = (PricingArea);


/***/ })

};
;