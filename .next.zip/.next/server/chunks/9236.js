"use strict";
exports.id = 9236;
exports.ids = [9236];
exports.modules = {

/***/ 9236:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ answer_question)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./src/data/answer-question-data.js


const answer_question_data = [
    {
        id: 1,
        question: "Who do you provide services for??",
        answer: /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
            children: "Ideally we provide services to NDIS & MyAgedCare Participants (Person with approved NDIS funding) however we can also help you step by step get NDIS approval if you are eligible."
        }),
        accordion_id: "headingOne",
        collapsed: "",
        data_bs_target: "#collapseOne",
        aria_expanded: true,
        aria_controls: "collapseOne",
        show: "show"
    },
    {
        id: 2,
        question: "What can I do with my plan now that it has been approved?",
        answer: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [
                "Frequently Asked Questions Who do you provide services for? Ideally we provide services to NDIS & MyAgedCare Participants (Person with approved NDIS funding) however we can also help you step by step get NDIS approval if you are eligible. What can I do with my plan now that it has been approved? Once your NDIS plan has been approved, you may begin contacting providers to begin receiving services you may be eligible for. To find out what you are eligible for, you can contact ",
                /*#__PURE__*/ jsx_runtime_.jsx("b", {
                    children: "Vserve Australia"
                }),
                " on  ",
                /*#__PURE__*/ jsx_runtime_.jsx("u", {
                    children: "1300 343 481"
                }),
                "."
            ]
        }),
        accordion_id: "headingTwo",
        collapsed: "collapsed",
        data_bs_target: "#collapseTwo",
        aria_expanded: false,
        aria_controls: "collapseTwo",
        show: ""
    },
    {
        id: 3,
        question: "What is a Support worker/Care Worker?",
        answer: /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
            children: "A Support Worker is an individual who is trained and qualified to provide supports to a person requiring supports either in home, hospital, nursing home or outside in the community."
        }),
        accordion_id: "headingThree",
        collapsed: "collapsed",
        data_bs_target: "#collapseThree",
        aria_expanded: false,
        aria_controls: "collapseThree",
        show: ""
    },
    {
        id: 4,
        question: "Do I get charged for the services?",
        answer: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [
                "We ",
                "don't",
                " charge clients for the services. Once approved from ",
                "NDIS/",
                " MyAgedCare, all your services are funded by NDIS."
            ]
        }),
        accordion_id: "headingFour",
        collapsed: "collapsed",
        data_bs_target: "#collapseFour",
        aria_expanded: false,
        aria_controls: "collapseFour",
        show: ""
    },
    {
        id: 5,
        question: "What are your service areas?",
        answer: /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
            children: "We provide services all over Sydney."
        }),
        accordion_id: "headingFive",
        collapsed: "collapsed",
        data_bs_target: "#collapseFive",
        aria_expanded: false,
        aria_controls: "collapseFive",
        show: ""
    },
    {
        id: 6,
        question: "I have more questions?",
        answer: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [
                "If you have more questions please contact us either by call on ",
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "tel:1300 343 481",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("u", {
                        children: "1300 343 481"
                    })
                }),
                " or write to us on ",
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "mailto:care@vserveaustralia.com.au",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("u", {
                        children: "care@vserveaustralia.com.au"
                    })
                })
            ]
        }),
        accordion_id: "headingSix",
        collapsed: "collapsed",
        data_bs_target: "#collapseSix",
        aria_expanded: false,
        aria_controls: "collapseSix",
        show: ""
    }
];
/* harmony default export */ const data_answer_question_data = (answer_question_data);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./src/common/answer-question.jsx



const AnswerQuestion = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "faq-accordion",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "accordion",
                id: "accordionExample",
                children: data_answer_question_data.map((item)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "accordion-items",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "accordion-header",
                                id: item.accordion_id,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: `accordion-button ${item.collapsed}`,
                                    type: "button",
                                    "data-bs-toggle": "collapse",
                                    "data-bs-target": item.data_bs_target,
                                    "aria-expanded": item.aria_expanded,
                                    "aria-controls": item.aria_controls,
                                    children: item.question
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                id: item.aria_controls,
                                className: `accordion-collapse collapse ${item.show}`,
                                "aria-labelledby": item.accordion_id,
                                "data-bs-parent": "#accordionExample",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "accordion-content",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: item.answer
                                    })
                                })
                            })
                        ]
                    }, item.id))
            })
        })
    });
};
/* harmony default export */ const answer_question = (AnswerQuestion);


/***/ })

};
;